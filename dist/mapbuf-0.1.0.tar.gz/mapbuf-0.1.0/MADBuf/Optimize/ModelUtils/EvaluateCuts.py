#!/usr/bin/env python
# -*- encoding=utf8 -*-

'''
Author: Hanyu Wang
Created time: 2023-03-31 18:49:52
Last Modified by: Hanyu Wang
Last Modified time: 2023-03-31 19:07:15
'''

from MADBuf.Network import *

def evaluate_signal_to_cuts(network: BLIFGraph, signal_to_cuts: dict, signal_to_channel: dict):

    # minimal label
    

    # check if all the channesl  
    
    
    for signal in signal_to_cuts:
        cuts = signal_to_cuts[signal]
