#!/usr/bin/env python
# -*- encoding=utf8 -*-

"""
Author: Hanyu Wang
Created time: 2023-03-19 02:06:10
Last Modified by: Hanyu Wang
Last Modified time: 2023-03-19 02:14:35
"""

from MADBuf.Optimize.Constraints.LatencyConstraints.LatencyPropagationConstraints import *
