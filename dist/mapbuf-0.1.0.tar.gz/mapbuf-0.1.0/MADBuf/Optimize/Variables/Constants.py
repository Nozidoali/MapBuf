#!/usr/bin/env python
# -*- encoding=utf8 -*-

"""
Author: Hanyu Wang
Created time: 2023-03-18 23:14:03
Last Modified by: Hanyu Wang
Last Modified time: 2023-03-18 23:14:59
"""


class MILPVariableConstants:
    r_valid: str = "_flop_valid"
    r_ready: str = "_flop_ready"
