#!/usr/bin/env python
# -*- encoding=utf8 -*-

"""
Author: Hanyu Wang
Created time: 2023-03-26 14:49:04
Last Modified by: Hanyu Wang
Last Modified time: 2023-03-26 16:00:18
"""

from MADBuf.Network import *


def create_blackbox(graph: BLIFGraph, signals_in_components):

    pass
